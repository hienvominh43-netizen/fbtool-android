FB TOOL MOBILE - HUONG DAN TAO APK BANG DIEN THOAI

Luu y: Moi truong hien tai khong co Android SDK/Gradle de xuat truc tiep APK da bien dich. Du an nay co workflow GitHub Actions de build APK tren may chu.

CACH LAM:
1. Tai file ZIP va giai nen tren dien thoai.
2. Dang nhap GitHub va tao repository moi, vi du: fbtool-mobile.
3. Tai cac file trong thu muc du an len repository, giu nguyen cau truc thu muc (bao gom .github/workflows/build.yml). Co the dung GitHub tren trinh duyet hoac app upload file.
4. Vao tab Actions cua repository, chon workflow "Build Android APK", bam Run workflow.
5. Khi build xong, mo lan chay workflow thanh cong va tai artifact "FBToolMobile-debug-apk". Giai nen artifact de lay app-debug.apk.
6. Mo APK tren dien thoai de cai dat. Android co the yeu cau cho phep cai ung dung tu nguon nay.

APK debug phu hop de thu nghiem/cai thu; khong phai ban phat hanh Play Store.

Ban nay la ban an toan co giao dien phong cach tuong tu va tien ich URL/UID co ban. Khong bao gom tu dong report hang loat, tu dong ket ban hay tu dong thao tac tai khoan.
